﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using AutoMapper;
using c360AzureService.Utils;
using c360AzureServiceCommon.Entities;
using log4net;
using Microsoft.Azure.ActiveDirectory.GraphClient;
using Microsoft.Azure.ActiveDirectory.GraphClient.Extensions;
using Swashbuckle.Swagger.Annotations;

namespace c360AzureService.Controllers
{
    /// <summary>
    /// Retrieve information about users from Azure Active Directory (AAD)
    /// </summary>
    public class UserController : ApiController
    {
        private readonly ILog _log = LogManager.GetLogger(typeof(UserController));
        private readonly IMapper _mapper;

        /// <summary>
        /// Constructor
        /// </summary>
        public UserController()
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.CreateMap<IUser, IUserResponse>());
            _mapper = config.CreateMapper();
        }

        //GET api/user/isalive
        /// <summary>
        /// Testing
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [SwaggerOperation("IsAlive")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        public IHttpActionResult IsAlive()
        {
            try
            {
                return Ok("I am alive!");
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return InternalServerError(ex);
            }
        }

        //POST api/user/getbyid
        /// <summary>
        /// Get user by Id
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/user/getbyid")]
        [SwaggerOperation("GetById")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        public IHttpActionResult GetById([FromBody] UserRequest request)
        {
            try
            {
                IUser user = GetUserFromActiveDirectory(request);
                IUserResponse model = _mapper.Map<IUserResponse>(user);
                return Ok(model);
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return InternalServerError(ex);
            }
        }

        //POST api/user/getUserGroupBelongs
        /// <summary>
        /// Recive a list of groups and returns the same list but with only the groups that the user belongs to
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/user/getUserGroupBelongs")]
        [SwaggerOperation(("GetUserGroupBelongs"))]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.BadRequest)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        public IHttpActionResult GetUserGroupBelongs([FromBody] UserRequest request)
        {
            try
            {
                IList<string> groupList = ServiceUtils.ConvertStringCommaSeparatedToList(request.GroupList);
                if (groupList.Any())
                {
                    IList<string> result = GetGroupsByUser(request.Token, request.TenantId, request.UserObjectId, groupList);
                    return Ok(result);
                }
                else
                {
                    return BadRequest("The property GroupList was not filled");
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return InternalServerError(ex);
            }
        }

        #region private methods

        private IList<string> GetGroupsByUser(string token, string tenantId, string userObjectId, IList<string> groupList)
        {
            IList<string> result = new List<string>();
            ActiveDirectoryUtils activeDirectoryUtils = new ActiveDirectoryUtils(token);
            ActiveDirectoryClient activeDirectory = activeDirectoryUtils.GetActiveDirectoryClient(tenantId);

            foreach (var group in groupList)
            {
                try
                {
                    bool belongs = GetGroupFromAzureActiveDirectory(activeDirectory, group, userObjectId).GetAwaiter().GetResult();
                    if (belongs)
                    {
                        result.Add(group);
                    }
                }
                catch(Exception ex)
                {
                    _log.Debug(ex);
                    // ignored. If the user does not have access to the group, AAD will throw an error.
                }
            }
            return result;
        }

        private async Task<bool> GetGroupFromAzureActiveDirectory(ActiveDirectoryClient activeDirectoryClient, string azureActiveDirectoryGroup, string userObjectId)
        {
            bool result = false;
            var retrievedGroups = activeDirectoryClient.Groups.Where(g => g.ObjectId == azureActiveDirectoryGroup).ExecuteAsync().GetAwaiter().GetResult();
            IGroup group = retrievedGroups.CurrentPage.FirstOrDefault();
            if (@group is IGroupFetcher)
            {
                result = FindUserIntoGroup(group, userObjectId).GetAwaiter().GetResult();
            }
            return result;
        }
        private Task<bool> FindUserIntoGroup(IGroup group, string userObjectId)
        {
            bool result = false;
            IGroupFetcher groupFetcher = (IGroupFetcher)group;
            IPagedCollection<IDirectoryObject> directoryObjects = groupFetcher.Members.Where(m => m.ObjectId == userObjectId).ExecuteAsync().GetAwaiter().GetResult();
            while (directoryObjects != null)
            {
                IDirectoryObject directoryObject = directoryObjects.CurrentPage.FirstOrDefault(d => d.ObjectId == userObjectId);
                if (directoryObject is Microsoft.Azure.ActiveDirectory.GraphClient.User)
                {
                    result = true;
                    break;
                }
                directoryObjects = directoryObjects.MorePagesAvailable ? directoryObjects.GetNextPageAsync().Result : null;
            }
            return Task.FromResult(result);
        }

        private IUser GetUserFromActiveDirectory(UserRequest request)
        {
            ActiveDirectoryUtils activeDirectoryUtils = new ActiveDirectoryUtils(request.Token);
            ActiveDirectoryClient activeDirectory = activeDirectoryUtils.GetActiveDirectoryClient(request.TenantId);
            IUser user = activeDirectory.Users.Where(u => u.ObjectId.Equals(request.UserObjectId)).ExecuteAsync().Result.CurrentPage.ToList().FirstOrDefault();
            return user;
        }

        /// <summary>
        /// Don't remove this private method because is a Rafa's proof and maybe we need to develop something similar in the future
        /// </summary>
        /// <param name="activeDirectory"></param>
        /// <param name="request"></param>
        private void TestingRafaGroupsHierarchy(ActiveDirectoryClient activeDirectory, UserRequest request)
        {

            IGroup result1 = activeDirectory.Groups.Where(x => x.ObjectId == "6443565b-ef40-4834-8e42-8596fa9acc19").ExecuteAsync().Result.CurrentPage.ToList().First();
            IGroup result2 = activeDirectory.Groups.Where(x => x.ObjectId == "864b93c8-347b-4f6d-a172-57bc6fb20b6e").ExecuteAsync().Result.CurrentPage.ToList().First();
            IGroup result3 = activeDirectory.Groups.Where(x => x.ObjectId == "93a705e6-f5d3-4245-ab12-097d8487f342").ExecuteAsync().Result.CurrentPage.ToList().First();
            IGroup result4 = activeDirectory.Groups.Where(x => x.ObjectId == "764f7da0-bf8c-47ac-8b16-c4bb51b1a29f").ExecuteAsync().Result.CurrentPage.ToList().First();
            IGroup result5 = activeDirectory.Groups.Where(x => x.ObjectId == "e941ca21-fad1-4bc0-9c38-3b0d6899237d").ExecuteAsync().Result.CurrentPage.ToList().First();
            IGroup result6 = activeDirectory.Groups.Where(x => x.ObjectId == "fa0b1d29-a7d5-41d3-93e9-ad7abc74d713").ExecuteAsync().Result.CurrentPage.ToList().First();

            IUser useraa = activeDirectory.Users.Where(u => u.ObjectId == request.UserObjectId).ExecuteSingleAsync().Result;
            IUserFetcher userFetcher = (IUserFetcher)useraa;
            var highGroupHierarchy = "6443565b-ef40-4834-8e42-8596fa9acc19";

            IPagedCollection<IDirectoryObject> pagedCollection = userFetcher.MemberOf.ExecuteAsync().Result;
            do
            {
                List<IDirectoryObject> directoryObjects = pagedCollection.CurrentPage.ToList();
                foreach (IDirectoryObject directoryObject in directoryObjects)
                {
                    if (directoryObject is Group)
                    {
                        var group = directoryObject as Group;

                        // find current group memberOf other groups
                        IGroupFetcher groupFetcher = (IGroupFetcher)group;
                        IPagedCollection<IDirectoryObject> groupies = groupFetcher.MemberOf.ExecuteAsync().GetAwaiter().GetResult();
                        List<IDirectoryObject> directoryGroupies = groupies.CurrentPage.ToList();

                        if (group.ObjectId == highGroupHierarchy)
                        {
                            break;
                        }
                    }
                }
                pagedCollection = pagedCollection.GetNextPageAsync().Result;
            } while (pagedCollection != null);
        }

        #endregion
    }
}
