﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web.Http;
using c360AzureService.Utils;
using c360AzureServiceCommon.Entities;
using log4net;
using Microsoft.Azure.ActiveDirectory.GraphClient;
using Swashbuckle.Swagger.Annotations;

namespace c360AzureService.Controllers
{
    /// <summary>
    /// Retrieve information about groups from Azure Active Directory (AAD)
    /// </summary>
    public class GroupController : ApiController
    {
        #region properties

        private readonly ILog _log = LogManager.GetLogger(typeof(GroupController));
        private static readonly string MarketingGroupSecretKey = ConfigurationManager.AppSettings["marketingGroup:SecretKey"];
        private static readonly string MarketingGroupDatabase = ConfigurationManager.AppSettings["marketingGroup:database"];
        private static readonly string MarketingGroupMask = ConfigurationManager.AppSettings["marketingGroup:mask"];

        private string _connectionString = string.Empty;
        private readonly string _sqlQueryString = "SELECT CONVERT(VARCHAR(200),DimAadMarketingGroup_id), " +
                                                  "DimMarketingGroup_code " +
                                                  "FROM [dbo].[DimMarketingGroup] " +
                                                  "WHERE DimAadMarketingGroup_id IS NOT NULL";
        #endregion

        //POST api/user/isalive
        /// <summary>
        /// Testing
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [SwaggerOperation("IsAlive")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        public IHttpActionResult IsAlive()
        {
            try
            {
                return Ok("I am alive!");
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return InternalServerError(ex);
            }
        }

        //POST api/group/getbyid
        /// <summary>
        /// Todo
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/group/getbyid")]
        [SwaggerOperation("GetById")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        public IHttpActionResult GetById([FromBody] UserRequest request)
        {
            try
            {
                IGroup result = GetGroupFromActiveDirectory(request);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return InternalServerError(ex);
            }
        }

        //POST api/group/getMarketingGroups
        /// <summary>
        /// Todo
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/group/getMarketingGroups")]
        [SwaggerOperation(("GetMarketingGroups"))]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        public IHttpActionResult GetMarketingGroups([FromBody] GroupRequest request)
        {
            try
            {
                _connectionString = GetConnectionString(request.Token, request.Environment);
                IDictionary<string, string> result = GetMarketingGroupsFromDatabase();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return InternalServerError(ex);
            }
        }

        #region private methods

        private IDictionary<string, string> GetMarketingGroupsFromDatabase()
        {
            IDictionary<string, string> result = ProcessFromDatabase();
            return result;
        }

        private IGroup GetGroupFromActiveDirectory(UserRequest request)
        {
            IGroup result = new Group();
            IList<string> groupList = ServiceUtils.ConvertStringCommaSeparatedToList(request.GroupList);
            string group = groupList.FirstOrDefault();
            if (!string.IsNullOrEmpty(group))
            {
                var groupObjectId = group.Trim();
                ActiveDirectoryUtils activeDirectoryUtils = new ActiveDirectoryUtils(request.Token);
                ActiveDirectoryClient activeDirectory = activeDirectoryUtils.GetActiveDirectoryClient(request.TenantId);
                result = activeDirectory.Groups.Where(x => x.ObjectId == groupObjectId).ExecuteAsync().Result.CurrentPage.ToList().First();
            }
            return result;
        }

        private static string GetConnectionString(string token, string environment)
        {
            ActiveDirectoryUtils activeDirectoryUtils = new ActiveDirectoryUtils(token);
            string secretKeyValue = activeDirectoryUtils.GetKeyValueSecretKey(environment, MarketingGroupSecretKey);
            string connectionString = MarketingGroupDatabase.Replace(MarketingGroupMask, secretKeyValue);
            return connectionString;
        }

        private IDictionary<string, string> ProcessFromDatabase()
        {
            IDictionary<string, string> result = new Dictionary<string, string>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand command = new SqlCommand(_sqlQueryString, conn);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(reader[0].ToString(), reader[1].ToString());
                        }
                    }
                    conn.Close();
                }
                catch (Exception ex)
                {
                    //TODO. error treatment pending
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    throw ex;
                }
            }
            return result;
        }

        #endregion
    }
}
