﻿using System;
using System.Net;
using System.Web.Http;
using System.Web.Http.Cors;
using c360AzureService.Utils;
using c360AzureServiceCommon.Entities;
using log4net;
using Swashbuckle.Swagger.Annotations;

namespace c360AzureService.Controllers
{
    /// <summary>
    /// Retrieve values from Azure KeyVault service
    /// </summary>
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class KeyVaultController : ApiController
    {
        private readonly ILog _log = LogManager.GetLogger(typeof(KeyVaultController));

        //POST api/keyvault/isalive
        /// <summary>
        /// Testing
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        [SwaggerOperation("IsAlive")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        public IHttpActionResult IsAlive()
        {
            try
            {
                return Ok("I am alive!");
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return InternalServerError(ex);
            }
        }

        //POST api/group/getbyid
        /// <summary>
        /// Get KeyVault value related to the secret key received
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/keyVault/GetSecret")]
        [SwaggerOperation("GetSecret")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        public IHttpActionResult GetSecret([FromBody]KeyVaultRequest request)
        {
            try
            {
                ActiveDirectoryUtils activeDirectoryUtils = new ActiveDirectoryUtils(string.Empty);  // for retrieve a secret key is not needed cause create it's own token
                string result = activeDirectoryUtils.GetKeyValueSecretKey(request.Env, request.SecretKey);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return InternalServerError(ex);
            }
        }
    }
}
