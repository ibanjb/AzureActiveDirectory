﻿using System;
using System.Configuration;
using System.Threading.Tasks;
using log4net;
using Microsoft.Azure.ActiveDirectory.GraphClient;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace c360AzureService.Utils
{
    /// <summary>
    /// ActiveDirectoryUtils
    /// </summary>
    public class ActiveDirectoryUtils
    {
        private readonly ILog _log = LogManager.GetLogger(typeof(ActiveDirectoryUtils));
        private static readonly string GraphResourceId = "https://graph.windows.net";
        private static readonly string IdaClientId = ConfigurationManager.AppSettings["ida:ClientId"];
        private static readonly string IdaClientSecret = ConfigurationManager.AppSettings["ida:Password"];

        private readonly string _hubEndpoint = ConfigurationManager.AppSettings["secretEndpoint:Hub"];
        private readonly string _midEndpoint = ConfigurationManager.AppSettings["secretEndpoint:Mid"];

        private readonly string _token;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="token"></param>
        public ActiveDirectoryUtils(string token)
        {
            _token = token;
        }

        /// <summary>
        /// Get ActiveDirectory client
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        public ActiveDirectoryClient GetActiveDirectoryClient(string tenantId)
        {
            Uri servicePointUri = new Uri(GraphResourceId);
            Uri serviceRoot = new Uri(servicePointUri, tenantId);
            ActiveDirectoryClient activeDirectoryClient = new ActiveDirectoryClient(serviceRoot, async () => ReportToken());
            return activeDirectoryClient;
        }

        /// <summary>
        /// Returns the value of the secret key received
        /// </summary>
        /// <param name="environment"></param>
        /// <param name="secretKey"></param>
        /// <returns></returns>
        public string GetKeyValueSecretKey(string environment, string secretKey)
        {
            string secretUri = GetSecretUriFromKey(environment, secretKey);
            string result = RetrieveSecretValueByKey(secretUri);
            return result;
        }

        private string ReportToken()
        {
            return _token;
        }

        private string GetSecretUriFromKey(string environment, string secretKey)
        {
            string result = string.Empty;
            switch (environment.ToLower())
            {
                case "hub":
                    result = _hubEndpoint + secretKey;
                    break;
                case "mid":
                    result = _midEndpoint + secretKey;
                    break;
            }
            _log.Debug("Secret URL: " + result);
            return result;
        }

        private string RetrieveSecretValueByKey(string secretUri)
        {
            string result = String.Empty;
            SecretBundle secretBundle = GetSecretAsync(secretUri).GetAwaiter().GetResult();
            if (secretBundle != null)
            {
                result = secretBundle.Value;
            }
            return result;
        }

        private async Task<SecretBundle> GetSecretAsync(string secretUri)
        {
            try
            {
                KeyVaultClient kv = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(GetToken));
                return kv.GetSecretAsync(secretUri).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                return null;
            }
        }

        private static async Task<string> GetToken(string authority, string resource, string scope)
        {
            var authContext = new AuthenticationContext(authority);
            ClientCredential clientCred = new ClientCredential(IdaClientId, IdaClientSecret);
            AuthenticationResult result = await authContext.AcquireTokenAsync(resource, clientCred);

            if (result == null)
            {
                throw new InvalidOperationException("Failed to obtain the JWT token");
            }
            return result.AccessToken;
        }
    }
}