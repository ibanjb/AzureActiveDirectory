﻿using System.Collections.Generic;
using System.Linq;

namespace c360AzureService.Utils
{
    /// <summary>
    /// Different utilities for the API service
    /// </summary>
    public static class ServiceUtils
    {
        /// <summary>
        /// Convert a plain string with values separated with commas into a IList with T as string object
        /// </summary>
        /// <param name="stringCommaSeparated"></param>
        /// <returns></returns>
        public static IList<string> ConvertStringCommaSeparatedToList(string stringCommaSeparated)
        {
            IList<string> result = new List<string>();
            if (stringCommaSeparated.Contains(","))
            {
                result = new List<string>(stringCommaSeparated.Split(',').Select(s => s.ToString()));
            }
            else
            {
                result.Add(stringCommaSeparated);
            }
            return result;
        }
    }
}