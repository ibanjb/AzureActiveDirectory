﻿using System.Configuration;
using Microsoft.Owin.Security.ActiveDirectory;
using Owin;

namespace c360AzureService
{
    public partial class Startup
    {
        // For more information on configuring authentication, please visit https://go.microsoft.com/fwlink/?LinkId=301864
        public void ConfigureAuth(IAppBuilder app)
        {
            var azureActiveDirectoryBearer = new WindowsAzureActiveDirectoryBearerAuthenticationOptions
            {
                Tenant = ConfigurationManager.AppSettings["ida:Tenant"],
                TokenValidationParameters = new System.IdentityModel.Tokens.TokenValidationParameters()
                {
                    ValidAudience = ConfigurationManager.AppSettings["ida:audience"]
                }
            };

            app.UseWindowsAzureActiveDirectoryBearerAuthentication(azureActiveDirectoryBearer);
        }
    }
}
