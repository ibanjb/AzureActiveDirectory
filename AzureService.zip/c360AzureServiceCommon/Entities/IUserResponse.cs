﻿using System.Collections.Generic;

namespace c360AzureServiceCommon.Entities
{
    public interface IUserResponse
    {
        string City { get; set; }

        string CompanyName { get; set; }

        string Country { get; set; }

        string Department { get; set; }

        string DisplayName { get; set; }

        string GivenName { get; set; }

        string JobTitle { get; set; }

        string Mail { get; set; }

        string MailNickname { get; set; }

        string Mobile { get; set; }

        IList<string> OtherMails { get; }

        string PostalCode { get; set; }

        string PreferredLanguage { get; set; }

        string State { get; set; }

        string StreetAddress { get; set; }

        string Surname { get; set; }

        string TelephoneNumber { get; set; }

        string UsageLocation { get; set; }

        string UserPrincipalName { get; set; }

        string UserType { get; set; }
    }
}