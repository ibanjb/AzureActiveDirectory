﻿namespace c360AzureServiceCommon.Entities
{
    public interface IGroupRequest : IUserRequest
    {
        string Environment { get; set; }
    }
}