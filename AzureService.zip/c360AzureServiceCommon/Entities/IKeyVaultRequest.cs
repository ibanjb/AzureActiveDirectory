﻿namespace c360AzureServiceCommon.Entities
{
    public interface IKeyVaultRequest
    {
        string Env { get; set; }

        string SecretKey { get; set; }
    }
}