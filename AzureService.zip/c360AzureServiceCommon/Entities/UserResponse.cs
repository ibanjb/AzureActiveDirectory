﻿using System.Collections.Generic;

namespace c360AzureServiceCommon.Entities
{
    /// <summary>
    /// User response entity model
    /// See more at <see cref="http://msdn.microsoft.com/en-us/library/azure/ad/graph/api/users-operations"/>
    /// </summary>
    public class UserResponse : IUserResponse
    {
        public string City { get; set; }
        public string CompanyName { get; set; }
        public string Country { get; set; }
        public string Department { get; set; }
        public string DisplayName { get; set; }
        public string GivenName { get; set; }
        public string JobTitle { get; set; }
        public string Mail { get; set; }
        public string MailNickname { get; set; }
        public string Mobile { get; set; }
        public IList<string> OtherMails { get; }
        public string PostalCode { get; set; }
        public string PreferredLanguage { get; set; }
        public string State { get; set; }
        public string StreetAddress { get; set; }
        public string Surname { get; set; }
        public string TelephoneNumber { get; set; }
        public string UsageLocation { get; set; }
        public string UserPrincipalName { get; set; }
        public string UserType { get; set; }
    }
}
