﻿using System.Collections.Generic;

namespace c360AzureServiceCommon.Entities
{
    public interface IUserRequest
    {
        string Token { get; set; }

        string TenantId { get; set; }

        string UserObjectId { get; set; }

        string GroupList { get; set; }
    }
}