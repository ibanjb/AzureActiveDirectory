﻿namespace c360AzureServiceCommon.Entities
{
    public class GroupRequest : IGroupRequest
    {
        public string Token { get; set; }

        public string TenantId { get; set; }

        public string UserObjectId { get; set; }

        public string GroupList { get; set; }

        public string Environment { get; set; }
    }
}
