﻿namespace c360AzureServiceCommon.Entities
{
    public class KeyVaultRequest : IKeyVaultRequest
    {
        public string Env { get; set; }

        public string SecretKey { get; set; }
    }
}
