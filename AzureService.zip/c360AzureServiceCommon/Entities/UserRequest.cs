﻿using System.Collections.Generic;

namespace c360AzureServiceCommon.Entities
{
    /// <summary>
    /// User request entity model
    /// See more at <see cref="http://msdn.microsoft.com/en-us/library/azure/ad/graph/api/users-operations"/>
    /// </summary>
    public class UserRequest : IUserRequest
    {
        public string Token { get; set; }

        public string TenantId { get; set; }

        public string UserObjectId { get; set; }

        public string GroupList { get; set; }
    }
}
