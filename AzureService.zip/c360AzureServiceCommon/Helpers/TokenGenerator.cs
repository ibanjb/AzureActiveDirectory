﻿using System;
using System.Configuration;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace c360AzureServiceCommon.Helpers
{
    public static class TokenGenerator
    {
        private const string ObjectIdentifierSchema = "http://schemas.microsoft.com/identity/claims/objectidentifier";
        private static readonly string ClientId = ConfigurationManager.AppSettings["ida:ClientId"];
        private static readonly string AppKey = ConfigurationManager.AppSettings["ida:ClientSecret"];
        private static readonly string Authority = ConfigurationManager.AppSettings["ida:Authority"];
        private static readonly string GraphResourceId = ConfigurationManager.AppSettings["ida:GraphUrl"];

        public static string GetToken()
        {
            string userObjectId = string.Empty;
            if (ClaimsPrincipal.Current != null && ClaimsPrincipal.Current.FindFirst(ObjectIdentifierSchema) != null)
            {
                userObjectId = ClaimsPrincipal.Current.FindFirst(ObjectIdentifierSchema).Value;
            }
            string token = GetTokenForApplication(userObjectId);
            return token;
        }

        private static string GetTokenForApplication(string userObjectId)
        {
            string token = string.Empty;
            ClientCredential clientcred = new ClientCredential(ClientId, AppKey);
            AuthenticationContext authenticationContext = new AuthenticationContext(Authority, true);
            try
            {
                AuthenticationResult authenticationResult = authenticationContext.AcquireTokenSilentAsync(GraphResourceId, clientcred, new UserIdentifier(userObjectId, UserIdentifierType.UniqueId)).GetAwaiter().GetResult();
                token = authenticationResult.AccessToken;
            }
            catch
            {
                token = GetTokenForApplicationTimed(authenticationContext, clientcred);
            }
            return token;
        }

        /// <summary>
        /// The second try to retrieve a valid token must be put it in a timeout task of n seconds due external problems to retrieve it (thx Microsoft!)
        /// </summary>
        /// <param name="authenticationContext"></param>
        /// <param name="clientcred"></param>
        /// <returns></returns>
        private static string GetTokenForApplicationTimed(AuthenticationContext authenticationContext, ClientCredential clientcred)
        {
            var task = Task.Run(() => TaskGetForTokenForApplicationTimed(authenticationContext, clientcred));
            if (task.Wait(TimeSpan.FromSeconds(5)))
            {
                return task.Result;
            }
            else
            {
                throw new Exception("Impossible to retrieve a valid token for the application");
            }
        }

        private static string TaskGetForTokenForApplicationTimed(AuthenticationContext authenticationContext, ClientCredential clientcred)
        {
            AuthenticationResult authenticationResult = authenticationContext.AcquireTokenAsync(GraphResourceId, clientcred).GetAwaiter().GetResult();
            return authenticationResult.AccessToken;
        }
    }
}
