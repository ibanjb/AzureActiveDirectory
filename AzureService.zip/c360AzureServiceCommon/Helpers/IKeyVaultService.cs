﻿using c360AzureServiceCommon.Enums;

namespace c360AzureServiceCommon.Helpers
{
    public interface IKeyVaultService
    {
        string GetSecretByKey(string serviceUrl, AzureEnvironment environment, string token, string secretKey);
    }
}