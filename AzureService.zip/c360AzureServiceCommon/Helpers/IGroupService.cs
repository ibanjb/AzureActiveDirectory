﻿using System.Collections.Generic;

namespace c360AzureServiceCommon.Helpers
{
    public interface IGroupService
    {
        IDictionary<string, string> GetMarketingGroups(string serviceUrl, string token, string tenantId, string userObjectId, string environment);

        IDictionary<string, string> GetMarketingGroupsFromSettings(string groupIdsFromSettings, string groupDescFromSettings);
    }
}