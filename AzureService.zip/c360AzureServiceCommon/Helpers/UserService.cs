﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using c360AzureServiceCommon.Entities;
using c360AzureServiceCommon.JsonSerializer;

namespace c360AzureServiceCommon.Helpers
{
    public class UserService : IUserService
    {
        public Guid AuthenticationGroupId { get; set; }

        private const string ApiGetById = "/api/user/GetById";
        private const string ApiGetUserGroupsBelongs = "/api/user/GetUserGroupBelongs";
        private const string MediaType = "application/x-www-form-urlencoded";

        /// <summary>
        /// Wrapper to call at c360 Azure Service API
        /// </summary>
        /// <param name="serviceUrl">Example: https://c360devazureservice.azurewebsites.net </param>
        /// <param name="token"></param>
        /// <param name="tenantId"></param>
        /// <param name="userObjectId"></param>
        /// <returns></returns>
        public IUserResponse GetUser(string serviceUrl, string token, string tenantId, string userObjectId)
        {
            IUserResponse userResponse = new UserResponse();
            try
            {
                string url = serviceUrl + ApiGetById;
                string formData = $"token={token}&tenantId={tenantId}&userObjectId={userObjectId}";
                HttpResponseMessage response = CallToService(token, url, formData);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream content = response.Content.ReadAsStreamAsync().GetAwaiter().GetResult();
                    userResponse = DeserializeService.Deserialize<UserResponse>(content);
                }
            }
            catch (Exception ex)
            {
                //TODO. error treatment pending
                throw ex;
            }

            return userResponse;
        }

        public IList<string> GetGroupsBelongsToUserFromList(string serviceUrl, string token, string tenantId, string userObjectId, IList<string> groups)
        {
            IList<string> result = new List<string>();
            string url = serviceUrl + ApiGetUserGroupsBelongs;
            string joined = string.Join(",", groups);
            string formData = $"token={token}&tenantId={tenantId}&userObjectId={userObjectId}&groupList={joined}";
            HttpResponseMessage response = CallToService(token, url, formData);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream content = response.Content.ReadAsStreamAsync().GetAwaiter().GetResult();
                result = DeserializeService.Deserialize<IList<string>>(content);
            }
            return result;
        }

        private HttpResponseMessage CallToService(string token, string url, string formData)
        {
            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            HttpResponseMessage response = httpClient.PostAsync(url, new StringContent(formData, Encoding.UTF8, MediaType))
                .Result;
            return response;
        }
    }
}
