﻿using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using c360AzureServiceCommon.Enums;
using c360AzureServiceCommon.JsonSerializer;

namespace c360AzureServiceCommon.Helpers
{
    /// <summary>
    /// AAD KeyVault methodologies. In the App.config you will find where to retrieve the required fields for the constructor
    /// </summary>
    public class KeyVaultService : IKeyVaultService
    {
        private const string ApiGetSecret = "/api/keyVault/GetSecret";

        /// <summary>
        /// Retrieve the secret value
        /// </summary>
        /// <param name="serviceUrl"></param>
        /// <param name="environment"></param>
        /// <param name="token"></param>
        /// <param name="secretKey"></param>
        /// <returns></returns>
        public string GetSecretByKey(string serviceUrl, AzureEnvironment environment, string token, string secretKey)
        {
            try
            {
                string url = serviceUrl + ApiGetSecret;
                string env = string.Empty;
                switch (environment)
                {
                    case AzureEnvironment.Hub:
                        env = "hub";
                        break;
                    case AzureEnvironment.Mid:
                        env = "mid";
                        break;
                }

                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                string formData = "&env=" + env + "&secretKey=" + secretKey;

                HttpResponseMessage response = httpClient.PostAsync(url, new StringContent(formData, Encoding.UTF8, "application/x-www-form-urlencoded")).Result;

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream content = response.Content.ReadAsStreamAsync().GetAwaiter().GetResult();
                    string secretValue = DeserializeService.Deserialize<string>(content);
                    return secretValue;
                }
                else
                {
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                //TODO. error treatment pending
                throw ex;
            }
        }
    }
}
