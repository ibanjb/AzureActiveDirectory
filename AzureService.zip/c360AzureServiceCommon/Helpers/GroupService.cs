﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using c360AzureServiceCommon.JsonSerializer;

namespace c360AzureServiceCommon.Helpers
{
    public class GroupService : IGroupService
    {
        private const string ApiGetMarketingGroups = "/api/group/getMarketingGroups";
        private const string MediaType = "application/x-www-form-urlencoded";

        private readonly IUserService _userService;

        public GroupService()
        {
            _userService = new UserService();
        }

        /// <summary>
        /// Get all the marketing groups that user belongs to
        /// </summary>
        /// <param name="serviceUrl"></param>
        /// <param name="token"></param>
        /// <param name="tenantId"></param>
        /// <param name="userObjectId"></param>
        /// <param name="environment"></param>
        /// <returns></returns>
        public IDictionary<string, string> GetMarketingGroups(string serviceUrl, string token, string tenantId, string userObjectId, string environment)
        {
            IDictionary<string, string> marketingGroupsDictionary = GetMarketingGroupsFromService(serviceUrl, token, tenantId, userObjectId, environment);
            IList<string> groups = marketingGroupsDictionary.Select(x => x.Key).ToList();

            IList<string> groupsAuthorized = _userService.GetGroupsBelongsToUserFromList(serviceUrl, token, tenantId, userObjectId, groups);
            IDictionary<string, string> result = marketingGroupsDictionary.Where(x => groupsAuthorized.Contains(x.Key)).ToDictionary(i => i.Key, i => i.Value);

            return result;
        }

        /// <summary>
        /// Retrieve marketing groups from settings received by parameters
        /// </summary>
        /// <param name="groupIdsFromSettings"></param>
        /// <param name="groupDescFromSettings"></param>
        /// <returns></returns>
        public IDictionary<string, string> GetMarketingGroupsFromSettings(string groupIdsFromSettings, string groupDescFromSettings)
        {
            IDictionary<string, string> result = new Dictionary<string, string>();
            if (!string.IsNullOrEmpty(groupIdsFromSettings) && !string.IsNullOrEmpty(groupDescFromSettings))
            {
                IList<string> marketingGroupIds = groupIdsFromSettings.Split(',').ToList();
                IList<string> marketingGroupDescriptions = groupDescFromSettings.Split(',').ToList();

                for (var i = 0; i < marketingGroupIds.Count; i++)
                {
                    string id = marketingGroupIds[i];
                    string description = marketingGroupDescriptions[i].Replace("'", "").Replace("'", "");
                    result.Add(id, description);
                }
            }
            return result;
        }

        #region private methods 

        private IDictionary<string, string> GetMarketingGroupsFromService(string serviceUrl, string token, string tenantId, string userObjectId, string environment)
        {
            IDictionary<string, string> result = new Dictionary<string, string>();
            try
            {
                string url = serviceUrl + ApiGetMarketingGroups;
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                string formData = $"token={token}&tenantId={tenantId}&userObjectId={userObjectId}&environment={environment}";

                HttpResponseMessage response = httpClient.PostAsync(url, new StringContent(formData, Encoding.UTF8, MediaType)).Result;
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream content = response.Content.ReadAsStreamAsync().GetAwaiter().GetResult();
                    result = DeserializeService.Deserialize<IDictionary<string, string>>(content);
                }
            }
            catch (Exception ex)
            {
                //TODO. error treatment pending
                throw ex;
            }
            return result;
        }

        #endregion
    }
}
