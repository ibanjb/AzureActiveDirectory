﻿using System;
using System.Collections.Generic;
using c360AzureServiceCommon.Entities;

namespace c360AzureServiceCommon.Helpers
{
    public interface IUserService
    {
        Guid AuthenticationGroupId { get; set; }

        IUserResponse GetUser(string serviceUrl, string token, string tenantId, string userObjectId);

        IList<string> GetGroupsBelongsToUserFromList(string serviceUrl, string token, string tenantId, string userObjectId, IList<string> groups);
    }
}