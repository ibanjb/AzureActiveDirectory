﻿using System.IO;
using Newtonsoft.Json;

namespace c360AzureServiceCommon.JsonSerializer
{
    /// <summary>
    /// Deserialize from a StreamReader to an typed object
    /// </summary>
    public static class DeserializeService
    {
        /// <summary>
        /// Deserialize from Stream to an object of type T
        /// </summary>
        /// <typeparam name="T">Object type to deserialize</typeparam>
        /// <param name="stream"></param>
        /// <returns></returns>
        public static T Deserialize<T>(Stream stream)
        {
            StreamReader reader = new StreamReader(stream);
            JsonTextReader jsonReader = new JsonTextReader(reader);
            Newtonsoft.Json.JsonSerializer ser = new Newtonsoft.Json.JsonSerializer();
            return ser.Deserialize<T>(jsonReader);
        }

    }
}
