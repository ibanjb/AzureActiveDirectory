﻿using System;
using System.Collections.Generic;
using c360AzureServiceCommon.Entities;
using c360AzureServiceCommon.Helpers;

namespace c360AzureServiceCommon.Mocks
{
    public class UserServiceMock : IUserService
    {
        public Guid AuthenticationGroupId { get; set; }
        public IUserResponse GetUser(string serviceUrl, string token, string tenantId, string userObjectId)
        {
            IUserResponse userResponse = new UserResponse();
            userResponse.Mail = string.Empty;
            return userResponse;
        }

        public IList<string> GetGroupsBelongsToUserFromList(string serviceUrl, string token, string tenantId, string userObjectId, IList<string> groups)
        {
            IList<string> result = groups;
            return result;
        }
    }
}
