﻿using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using c360AzureServiceCommon.Helpers;

namespace c360AzureServiceCommon.Mocks
{
    public class GroupServiceMock : IGroupService
    {
        private readonly string _groupIdsFromSettings = ConfigurationManager.AppSettings["allowed:MarketingGroupIds"];
        private readonly string _groupDescFromSettings = ConfigurationManager.AppSettings["allowed:MarketingGroupDescriptions"];

        public IDictionary<string, string> GetMarketingGroups(string serviceUrl, string token, string tenantId, string userObjectId, string environment)
        {
            IDictionary<string, string> result = GetMockMarketingGroupList();
            return result;
        }

        public IDictionary<string, string> GetMarketingGroupsFromSettings(string groupIdsFromSettings, string groupDescFromSettings)
        {
            IDictionary<string, string> result = GetMockMarketingGroupList();
            return result;
        }

        private IDictionary<string, string> GetMockMarketingGroupList()
        {
            IDictionary<string, string> result = new Dictionary<string, string>();
            if (!string.IsNullOrEmpty(_groupIdsFromSettings) && !string.IsNullOrEmpty(_groupDescFromSettings))
            {
                IList<string> marketingGroupIds = _groupIdsFromSettings.Split(',').ToList();
                IList<string> marketingGroupDescriptions = _groupDescFromSettings.Split(',').ToList();

                for (var i = 0; i < marketingGroupIds.Count; i++)
                {
                    string id = marketingGroupIds[i];
                    string description = marketingGroupDescriptions[i].Replace("'", "").Replace("'", "");
                    result.Add(id, description);
                }
            }
            return result;
        }
    }
}
