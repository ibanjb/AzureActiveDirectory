﻿namespace c360AzureServiceCommon.Enums
{
    public enum AzureEnvironment
    {
        Hub,
        Mid
    }
}